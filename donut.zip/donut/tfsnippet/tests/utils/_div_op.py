# -*- coding: utf-8 -*-


def regular_div(x, y):
    return x / y


def floor_div(x, y):
    return x // y
