from .collect_outputs_ import *

__all__ = [
    'collect_outputs',
]
