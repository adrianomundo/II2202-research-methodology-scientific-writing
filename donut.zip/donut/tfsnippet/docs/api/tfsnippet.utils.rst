tfsnippet.utils
===============

.. automodapi:: tfsnippet.utils
