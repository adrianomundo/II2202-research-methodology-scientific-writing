tfsnippet\.layers
=================

.. automodapi:: tfsnippet.layers
