zhusuan\.diagnostics 
===========================

.. automodule:: zhusuan.diagnostics
    :members:
    :undoc-members:
    :show-inheritance:
