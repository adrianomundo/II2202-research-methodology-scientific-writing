zhusuan\.sgmcmc 
============================

.. automodule:: zhusuan.sgmcmc
    :members:
    :undoc-members:
    :show-inheritance:
