zhusuan\.utils 
=====================

.. automodule:: zhusuan.utils
    :members:
    :undoc-members:
    :show-inheritance:
