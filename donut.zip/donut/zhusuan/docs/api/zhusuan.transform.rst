zhusuan\.transform 
=========================

.. automodule:: zhusuan.transform
    :members:
    :undoc-members:
    :show-inheritance:
