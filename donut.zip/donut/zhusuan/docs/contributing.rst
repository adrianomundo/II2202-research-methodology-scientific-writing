Contributing
============

We always welcome contributions to help make ZhuSuan better. If you would like
to contribute, please check out the
`guidelines <https://github.com/thu-ml/zhusuan/blob/master/CONTRIBUTING.md>`_
here. Below are an incomplete list of our contributors (find more on
`this page <https://github.com/thu-ml/zhusuan/graphs/contributors>`_).

* Jiaxin Shi (`thjashin <https://github.com/thjashin>`_)
* Jianfei Chen (`cjf00000 <https://github.com/cjf00000>`_)
* Shengyang Sun (`ssydasheng <https://github.com/ssydasheng>`_)
* Yucen Luo (`xinmei9322 <https://github.com/xinmei9322>`_)
* Yihong Gu (`wmyw96 <https://github.com/wmyw96>`_)
* Yuhao Zhou (`miskcoo <https://github.com/miskcoo>`_)
* Ziyu Wang (`meta-inf <https://github.com/meta-inf>`_)
* Alexander Botev (`botev <https://github.com/botev>`_)
* Shuyu Cheng (`csy530216 <https://github.com/csy530216>`_)
* Haowen Xu (`korepwx <https://github.com/korepwx>`_)
* Huajun Wu (`CaptainMushroom <https://github.com/CaptainMushroom>`_)
